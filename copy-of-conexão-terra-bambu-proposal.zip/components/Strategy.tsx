
import React from 'react';
import { motion } from 'framer-motion';
import { Video, BookOpen, FileText, Globe, Heart, Sprout, Hammer, Ruler, Share2, MessageCircle } from 'lucide-react';
import { StrategyItem, VisualType } from '../types';

// Images for background content (Photos inside the mockups)
const IMAGES = {
  shorts: "https://images.unsplash.com/photo-1595856942697-39e25d2b7044?q=80&w=800&auto=format&fit=crop", 
  // Changed image to Bamboo Structure/Roof (Forros)
  landingPage: "https://images.unsplash.com/photo-1633989464081-16ccd3128afd?q=80&w=1600&auto=format&fit=crop", 
  blog: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1600&auto=format&fit=crop", // Forest
};

const strategyItems: StrategyItem[] = [
  {
    id: 1,
    title: "Shorts/Reels",
    subtitle: "Alcance Diário",
    description: "31 posts agendados automaticamente, garantindo frequência ininterrupta e reativação do algoritmo.",
    metric: "50% Vendas + 50% Autoridade",
    icon: Video,
    visualType: 'mobile',
    visualSrc: IMAGES.shorts
  },
  {
    id: 2,
    title: "Landing Page",
    subtitle: "Conversão Imediata",
    description: "Página de alta conversão para Estruturas Modulares (Forros, Cercas, Divisórias) em 3 idiomas.",
    metric: "Foco nas Estruturas Modulares",
    icon: Globe,
    visualType: 'browser',
    visualSrc: IMAGES.landingPage
  },
  {
    id: 3,
    title: "Blog (SEO)",
    subtitle: "Autoridade Global",
    description: "4 artigos otimizados para SEO, atraindo tráfego orgânico e educando sobre Bioconstrução em 3 idiomas.",
    metric: "Posicionamento de autoridade",
    icon: FileText,
    visualType: 'browser-text',
    visualSrc: IMAGES.blog
  },
  {
    id: 4,
    title: "E-book",
    subtitle: "Lead Magnet",
    description: "Guia completo de Bambu em 3 idiomas, transformando leads mornos em interessados em Aulas/Vivências.",
    metric: "Captação e qualificação de leads",
    icon: BookOpen,
    visualType: 'book'
  }
];

// --- COMPONENTES VISUAIS (MOCKUPS GERADOS VIA CÓDIGO) ---

const MobileMockup = ({ src }: { src?: string }) => (
  <div className="group relative mx-auto w-40 h-80 bg-gray-900 rounded-[2rem] border-[6px] border-gray-800 shadow-2xl overflow-hidden transform transition-all duration-500 hover:scale-105 hover:shadow-terra-400/50">
    {/* Notch */}
    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-20 h-5 bg-gray-800 rounded-b-xl z-30" />
    
    <div className="w-full h-full relative bg-gray-800 overflow-hidden">
        <img 
          src={src} 
          alt="Reels Content" 
          className="w-full h-full object-cover opacity-90 transition-transform duration-700 ease-out group-hover:scale-110" 
        />
        
        {/* Interface Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/80 z-10 flex flex-col justify-between p-3 pointer-events-none">
            <div className="flex justify-between items-center mt-6">
                <span className="text-[8px] font-bold text-white/90">Terra Bambu</span>
                <div className="px-1.5 py-0.5 bg-red-600 rounded text-[6px] text-white font-bold animate-pulse">AO VIVO</div>
            </div>

            <div className="space-y-3 mb-4">
                 {/* Lateral Icons */}
                 <div className="absolute right-2 bottom-12 flex flex-col gap-3 items-center">
                    <div className="p-1.5 bg-black/40 backdrop-blur-md rounded-full">
                        <Heart size={14} className="text-white fill-white animate-bounce" />
                    </div>
                    <div className="p-1.5 bg-black/40 backdrop-blur-md rounded-full">
                        <MessageCircle size={14} className="text-white" />
                    </div>
                    <div className="p-1.5 bg-black/40 backdrop-blur-md rounded-full">
                        <Share2 size={14} className="text-white" />
                    </div>
                 </div>

                 <div className="flex items-center gap-2">
                     <div className="w-6 h-6 rounded-full bg-terra-400 border border-white" />
                     <div className="text-[8px] text-white">
                         <p className="font-bold">conexaoterrabambu</p>
                         <p className="opacity-80 line-clamp-1">Estruturas incríveis de...</p>
                     </div>
                 </div>
            </div>
        </div>

        {/* Progress Bar Animation */}
        <div className="absolute bottom-1 left-1 right-1 h-0.5 bg-white/30 rounded-full overflow-hidden z-20">
           <motion.div 
             initial={{ width: "0%" }}
             animate={{ width: "100%" }}
             transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
             className="h-full bg-terra-400"
           />
        </div>
    </div>
  </div>
);

const BrowserMockup = ({ src, textMode }: { src?: string, textMode?: boolean }) => (
  <div className="group relative mx-auto w-full max-w-[320px] aspect-[4/3] bg-white rounded-lg shadow-xl overflow-hidden border border-terra-200 transform transition-all duration-500 hover:scale-105 hover:-translate-y-2">
    {/* Browser Bar */}
    <div className="bg-terra-50 border-b border-terra-200 p-2 flex items-center gap-1.5 z-20 relative">
      <div className="flex gap-1">
          <div className="w-2 h-2 rounded-full bg-terra-300" />
          <div className="w-2 h-2 rounded-full bg-terra-300" />
      </div>
      <div className="ml-2 flex-1 h-4 bg-white rounded border border-terra-200 flex items-center px-2 shadow-sm">
         <div className="w-1.5 h-1.5 rounded-full bg-green-500/50"></div>
         <div className="w-16 h-1 bg-terra-100 ml-1.5 rounded-full"></div>
      </div>
    </div>
    
    {/* Content Window */}
    <div className="relative w-full h-full overflow-hidden bg-gray-50">
        <motion.div
           animate={{ y: ["0%", "-25%", "0%"] }}
           transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
           className="w-full origin-top transition-transform duration-700 group-hover:scale-105"
        >
           {/* Simulate Web Layout if it's text mode, otherwise image */}
           {textMode ? (
               <div className="bg-white min-h-[400px] p-4">
                   <div className="w-full h-32 bg-terra-100 rounded-lg mb-4 overflow-hidden relative group/image">
                        <img src={src} className="w-full h-full object-cover opacity-80 transition-transform duration-700 group-hover/image:scale-110" />
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <span className="text-terra-800 font-serif font-bold text-lg drop-shadow-md">Blog Terra Bambu</span>
                        </div>
                   </div>
                   <div className="space-y-3">
                       <div className="h-4 w-3/4 bg-terra-800 rounded" />
                       <div className="h-2 w-full bg-terra-200 rounded" />
                       <div className="h-2 w-full bg-terra-200 rounded" />
                       <div className="h-2 w-5/6 bg-terra-200 rounded" />
                       <div className="flex gap-2 mt-2">
                           <div className="h-16 w-1/3 bg-terra-50 rounded border border-terra-100" />
                           <div className="flex-1 space-y-2">
                               <div className="h-2 w-full bg-terra-200 rounded" />
                               <div className="h-2 w-full bg-terra-200 rounded" />
                           </div>
                       </div>
                   </div>
               </div>
           ) : (
               <img src={src} alt="Web Layout" className="w-full object-cover" />
           )}
        </motion.div>
    </div>
  </div>
);

const BookMockup = () => (
    <div className="relative mx-auto w-36 h-52 perspective-1000 group cursor-pointer mt-2">
      <motion.div 
          className="relative w-full h-full transform-style-3d shadow-2xl"
          whileHover={{ rotateY: -25, rotateX: 5, scale: 1.1 }}
          transition={{ type: "spring", stiffness: 100 }}
          style={{ transform: "rotateY(-15deg)" }}
      >
        {/* Front Cover (CSS Generated Art) */}
        <div className="absolute inset-0 bg-[#2C3E2D] rounded-r-sm border-l border-white/10 z-10 flex flex-col p-3 overflow-hidden">
             {/* Texture Overlay */}
             <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/canvas-orange.png')] opacity-20 mix-blend-overlay"></div>
             
             {/* Decorative Corners */}
             <div className="absolute -top-6 -right-6 w-16 h-16 border-4 border-terra-400/30 rounded-full" />
             <div className="absolute -bottom-6 -left-6 w-16 h-16 border-4 border-terra-400/30 rounded-full" />

             {/* Content */}
             <div className="relative z-10 flex flex-col h-full items-center justify-between py-2 border border-terra-400/20 rounded-sm">
                  <div className="flex flex-col items-center gap-1 mt-2">
                       <Sprout className="text-terra-400 w-8 h-8" />
                       <div className="h-px w-10 bg-terra-400/50"></div>
                  </div>

                  <div className="text-center space-y-1">
                      <p className="text-[8px] tracking-[0.2em] text-terra-200 uppercase font-sans">Guia Essencial</p>
                      <h2 className="text-2xl font-serif font-bold text-white leading-none tracking-tight">BAMBU</h2>
                      <p className="text-[6px] text-terra-300 max-w-[80px] mx-auto leading-tight">FORROS E CERCAS PARA CONSTRUÇÃO SUSTENTÁVEL</p>
                  </div>

                  {/* Illustration Area */}
                  <div className="w-16 h-16 relative">
                      <div className="absolute inset-0 border border-terra-400/30 transform rotate-45"></div>
                      <Hammer className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-terra-500 w-6 h-6 opacity-80" />
                      <Ruler className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-terra-300 w-8 h-8 opacity-40 transform -rotate-45" />
                  </div>

                  <div className="flex items-center gap-1 mb-1">
                      <div className="w-2 h-2 bg-white rounded-full opacity-80"></div>
                      <span className="text-[6px] font-bold text-white uppercase">Conexão Terra Bambu</span>
                  </div>
             </div>
        </div>
        
        {/* Pages (Side) */}
        <div className="absolute top-0.5 bottom-0.5 right-0 w-8 bg-[#fdfbf7] border-y border-r border-gray-300 transform translate-z-[-12px] translate-x-[0px] rotate-y-[90deg] shadow-[inset_2px_0_5px_rgba(0,0,0,0.1)]" 
             style={{ backgroundImage: "repeating-linear-gradient(to right, #e8e0d1 0px, #e8e0d1 1px, transparent 1px, transparent 4px)" }}
        />
        
         {/* Back Cover */}
         <div className="absolute inset-0 bg-[#243225] rounded-l-sm transform translate-z-[-24px]" />
      </motion.div>
      
      {/* Drop Shadow */}
      <div className="absolute -bottom-4 left-2 w-28 h-4 bg-black/40 blur-lg rounded-[100%] transform rotate-x-[60deg]" />
    </div>
);


const MockupRenderer: React.FC<{ type: VisualType; src?: string }> = ({ type, src }) => {
  if (type === 'mobile') return <MobileMockup src={src} />;
  if (type === 'browser') return <BrowserMockup src={src} />;
  if (type === 'browser-text') return <BrowserMockup src={src} textMode={true} />;
  if (type === 'book') return <BookMockup />;
  return null;
};

// Animation Variants
const cardVariants = {
  hidden: { opacity: 0, y: 40, scale: 0.95 },
  visible: (index: number) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: index * 0.1,
      duration: 0.6,
      ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
    },
  }),
};

export const Strategy: React.FC = () => {
  return (
    <section className="py-24 bg-terra-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
           <span className="text-terra-500 font-bold tracking-widest text-sm uppercase mb-2 block">O Ecossistema Digital 24/7</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-terra-900 mb-6">A Estratégia</h2>
          <p className="text-terra-700 max-w-2xl mx-auto text-lg leading-relaxed">
             Cada ativo foi desenhado para trabalhar em sincronia, gerando autoridade e vendas automáticas enquanto você foca na execução das obras.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {strategyItems.map((item, index) => (
            <motion.div
              key={item.id}
              custom={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={cardVariants}
              className="group h-full"
            >
              <div className="bg-white rounded-[2rem] p-6 shadow-xl shadow-terra-200/50 border border-white hover:border-terra-300 transition-all duration-300 h-full flex flex-col relative overflow-visible hover:-translate-y-2">
                
                {/* Visual Area */}
                <div className="relative z-10 h-64 flex items-center justify-center mb-6 -mt-12 group-hover:-mt-14 transition-all duration-300">
                    <MockupRenderer type={item.visualType} src={item.visualSrc} />
                </div>
                
                {/* Text Content */}
                <div className="relative z-10 flex-1 text-center">
                    <div className="flex items-center justify-center gap-2 mb-2">
                        <item.icon size={18} className="text-terra-500" />
                        <h3 className="text-xl font-bold text-terra-900">{item.title}</h3>
                    </div>
                    
                    <p className="text-xs font-bold text-terra-400 uppercase tracking-wider mb-4">
                        {item.subtitle}
                    </p>
                    
                    <p className="text-terra-600 text-sm mb-6 leading-relaxed">
                        {item.description}
                    </p>
                </div>

                {/* Metric Badge */}
                <div className="relative z-10 pt-4 mt-auto border-t border-terra-100">
                  <p className="text-xs font-semibold text-terra-800 bg-terra-50 py-2 px-3 rounded-lg w-full text-center">
                    🎯 {item.metric}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
