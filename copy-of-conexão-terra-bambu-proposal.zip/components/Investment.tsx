
import React from 'react';
import { motion } from 'framer-motion';
import { Check, Star } from 'lucide-react';

export const Investment: React.FC = () => {
  return (
    <section className="py-24 bg-white relative">
      <div className="max-w-6xl mx-auto px-4">
        
        <div className="grid md:grid-cols-2 gap-16 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 bg-terra-100 px-3 py-1 rounded-full text-terra-800 text-xs font-bold uppercase tracking-wider mb-4">
                <Star size={12} className="fill-terra-800" /> Transparência
            </div>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-terra-900 mb-6">Investimento & Valor</h2>
            <p className="text-terra-600 mb-10 text-lg leading-relaxed">
                Um pacote completo de aceleração digital. Você investe em 20 dias técnicos e recebe 31 dias de presença ininterrupta.
            </p>

            <div className="bg-terra-50 rounded-2xl p-6 border border-terra-100 shadow-inner">
                <h3 className="text-sm font-bold text-terra-800 mb-6 uppercase tracking-wider border-b border-terra-200 pb-2">Entregáveis (Os 7 Ativos):</h3>
                <ul className="space-y-4">
                    {[
                        "31 Shorts/Reels Agendados (Frequência diária garantida)",
                        "Landing Page em 3 Idiomas (Conversão de vendas)",
                        "E-book 'Lead Magnet' (Captação de e-mails)",
                        "4 Artigos de Blog (3 Idiomas) otimizados para SEO",
                        "Catálogo WhatsApp Otimizado (Venda imediata)",
                        "Implementação Técnica (Host/GitHub Escalável)",
                        "Relatório Final de KPIs + Plano Próximo Ciclo"
                    ].map((item, idx) => (
                        <motion.li 
                            key={idx}
                            initial={{ opacity: 0, x: -10 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.05 }}
                            className="flex items-start text-terra-700 text-sm md:text-base"
                        >
                            <span className="bg-green-100 p-1 rounded-full mr-3 mt-0.5 shrink-0 text-green-700">
                                <Check size={12} strokeWidth={3} />
                            </span>
                            <span className="leading-snug">{item}</span>
                        </motion.li>
                    ))}
                </ul>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            whileHover={{ y: -5 }}
            className="bg-terra-900 p-8 md:p-12 rounded-[2.5rem] shadow-2xl shadow-terra-900/40 text-center relative overflow-hidden group"
          >
            {/* Background Effects */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-terra-800 rounded-full blur-3xl opacity-50 -translate-y-1/2 translate-x-1/2 group-hover:bg-terra-700 transition-colors"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-terra-800 rounded-full blur-2xl opacity-30 translate-y-1/2 -translate-x-1/2"></div>
            
            <div className="relative z-10">
                <h3 className="text-terra-300 font-bold tracking-widest uppercase text-xs mb-4">Investimento Único</h3>
                <div className="flex items-start justify-center text-white mb-2">
                    <span className="text-2xl mt-2 mr-1">R$</span>
                    <span className="text-6xl md:text-7xl font-serif font-bold">3.000</span>
                    <span className="text-2xl mt-8">,00</span>
                </div>
                <p className="text-terra-200 font-medium mb-8">31 Dias de Ativação Global</p>

                <div className="space-y-3 text-sm text-terra-100 bg-white/5 backdrop-blur-md p-6 rounded-2xl border border-white/10 mb-8">
                    <div className="flex justify-between border-b border-white/10 pb-3">
                        <span className="opacity-80">Mão de Obra (DMO)</span>
                        <span className="font-bold">R$ 150,00/dia</span>
                    </div>
                    <div className="flex justify-between border-b border-white/10 pb-3">
                        <span className="opacity-80">Dedicação</span>
                        <span className="font-bold">20 dias úteis</span>
                    </div>
                    <div className="flex justify-between pt-1">
                        <span className="opacity-80">Cronograma</span>
                        <span className="font-bold text-terra-300">03/Dez a 01/Jan</span>
                    </div>
                </div>
                
                <p className="text-[10px] text-terra-400 uppercase tracking-widest opacity-60">
                    Full Stack Marketer no Comando
                </p>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
